import boto3
import json

def get_security_group_info(region, sg_identifier):
    """Fetch security group details, rules, and attached resources"""
    ec2 = boto3.client('ec2', region_name=region)
    
    # Identify SG by ID or Name
    sgs = ec2.describe_security_groups(Filters=[{'Name': 'group-id', 'Values': [sg_identifier]}])['SecurityGroups']
    if not sgs:
        sgs = ec2.describe_security_groups(Filters=[{'Name': 'group-name', 'Values': [sg_identifier]}])['SecurityGroups']
    if not sgs:
        print(f"Security Group '{sg_identifier}' not found in region {region}.")
        return None
    
    sg = sgs[0]  # Assume one SG found
    sg_id = sg['GroupId']
    sg_name = sg.get('GroupName', 'Unknown')
    vpc_id = sg.get('VpcId', 'Unknown')
    description = sg.get('Description', 'No description')

    # Get EC2 instances using SG
    instances = ec2.describe_instances(Filters=[{"Name": "instance.group-id", "Values": [sg_id]}])['Reservations']
    ec2_instances = [i['Instances'][0]['InstanceId'] for i in instances if i['Instances']]

    # Get RDS instances using SG
    rds_client = boto3.client('rds', region_name=region)
    rds_instances = [
        db['DBInstanceIdentifier']
        for db in rds_client.describe_db_instances()['DBInstances']
        if any(sg['VpcSecurityGroupId'] == sg_id for sg in db['VpcSecurityGroups'])
    ]

    # Get Load Balancers using SG
    elb_client = boto3.client('elbv2', region_name=region)
    elbs = [
        lb['LoadBalancerArn']
        for lb in elb_client.describe_load_balancers()['LoadBalancers']
        if sg_id in lb.get('SecurityGroups', [])
    ]

    # Format the report
    report = f"""
    AWS Security Group Report
    ==========================
    Region: {region}
    Security Group ID: {sg_id}
    Name: {sg_name}
    VPC: {vpc_id}
    Description: {description}
    
    Rules:
    ------
    {json.dumps(sg.get('IpPermissions', []), indent=4)}

    Attached Resources:
    -------------------
    EC2 Instances: {', '.join(ec2_instances) if ec2_instances else 'None'}
    RDS Instances: {', '.join(rds_instances) if rds_instances else 'None'}
    Load Balancers: {', '.join(elbs) if elbs else 'None'}
    """

    with open(f"sg_report_{sg_id}.txt", "w") as file:
        file.write(report)

    print(f"\nSecurity Group report saved: sg_report_{sg_id}.txt")

if __name__ == "__main__":
    region = input("Enter AWS Region: ").strip()
    sg_identifier = input("Enter Security Group ID or Name: ").strip()
    get_security_group_info(region, sg_identifier)
